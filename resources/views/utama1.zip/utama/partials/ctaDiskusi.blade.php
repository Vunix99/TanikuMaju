  <!-- Section 4 CTA -->
  <div class="section4 mx-0">
    <div class="container-fluid">
      <div class="row d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="col-md-12 text-center">
          <h2 class="fw-bold">Bicarakan <span style="color: #F7C35F;">Kebutuhan Pertanian</span> <br>
          Anda dengan<span style="color: #F7C35F;"> petani lainnya</span>
          </h2>
          <br>
          <a href="/diskusi" class="btn btn-lg btn-warning fw-bold">Mulai Diskusi</a>
        </div>
      </div>
    </div>
  </div>  